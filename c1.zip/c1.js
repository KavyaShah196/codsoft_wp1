document.addEventListener('DOMContentLoaded', () => {
    const heroText = document.querySelector('.hero h1');
    const heroSubText = document.querySelector('.hero p');
    const ctaButton = document.querySelector('.hero .cta');

    heroText.style.animation = 'fadeInDown 1s ease-out forwards';
    heroSubText.style.animation = 'fadeInUp 1s ease-out forwards';
    ctaButton.style.animation = 'fadeIn 2s ease-out forwards';
});
